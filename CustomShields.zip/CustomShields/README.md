# Custom Shields 2.2 (Fabric, Minecraft 1.21.11)

In-game: type **/customshield** in chat.
* A gallery of 16 coloured shields appears, plus a **+** shield.
* Click a colour -> your shield changes to that colour.
* Click **+** -> "Select PNG file" or "Select GIF / video" -> your computer's file picker opens
  -> pick a file -> it's put on your shield and the textures reload automatically.
* "Reset to normal shield" puts everything back.
(/customsheild and /customshields also work.)

## Saving shields (new in 2.1)
Pick a PNG/GIF/video (and a colour if you like), then:
* **/customshield save** - saves it as shield-1, shield-2, ...
* **/customshield save <name>** - saves it under a name (letters, numbers, - and _)
* or press **Save current** in the /customshield screen.

The gallery draws each shield as the real shield face (the same pixels the game uses), so what you see is what you get.
Saved shields show up in a row under the 16 colours, showing your actual picture (with a coloured rim if you gave it a colour; videos show a play icon).
Click one to put it back on your shield instantly - no file picker needed.
Up to 18 can be saved (use the < > buttons if there are more than 9).
**Delete: off/ON** switches to delete mode: click a saved shield to remove it.
Saving again with the same name replaces it. Saved shields live in `customshields/saved/`.

Requires **Fabric Loader 0.18.1+** and **Fabric API** (the Fabric API mod must be in your modpack).

## Getting the jar (no installs needed): GitHub builds it for you
1. Make a free GitHub account, click **New repository**, name it anything, make it Private.
2. Click **uploading an existing file**, drag in EVERYTHING from this folder
   (including the hidden `.github` folder), and commit.
   - If `.github` didn't upload: Actions tab -> "set up a workflow yourself" -> paste the contents of
     `.github/workflows/build.yml` -> commit.
3. Open the **Actions** tab, click the latest run (wait for the green tick, ~3-5 min).
4. At the bottom of the run, download the **customshields-jar** artifact and unzip it.
   Inside is `customshields-2.0.0.jar`.

(Or build locally: install JDK 21 + Gradle 9.2, run `gradle build`, jar is in build/libs.)

## Install in Modrinth App
1. Instance must be **Minecraft 1.21.11 + Fabric**, with **Fabric API** installed.
2. Remove the OLD customshields-1.0.0.jar if you added it earlier.
3. Instance -> Content -> Add content -> From file -> pick the jar.
4. Launch, join a world, type /customshield.
   (Very first launch only: restart once after choosing a design so the shield pack switches on.)

## Notes
* Only affects shields WITHOUT a banner on them (banner shields are tinted/patterned by the game).
* The colours are the shield's colour scheme: with a custom image, the colour is used for the back and
  rim; with no image, the whole face is that colour. They are not Mojang's banner dye shields.
* Videos need ffmpeg installed (or pick a GIF). Animations cap at 20 frames (edit `maxFrames`
  in `customshields/settings.properties`).
* Files you drop in the `customshields` folder by hand still work: wait ~3 s, then press F3+T.
* The file picker runs in a separate Java process. If it doesn't open (some Linux setups), drop your
  file into the `customshields` folder instead.

## Design note
All the logic that doesn't need Minecraft (building textures, GIF/video, settings, options.txt)
is in plain Java and has been tested. Only `client/ShieldScreen.java`, `client/CustomShieldsClient.java`
and `client/FilePicker.java` touch Minecraft's 1.21.11 classes.
