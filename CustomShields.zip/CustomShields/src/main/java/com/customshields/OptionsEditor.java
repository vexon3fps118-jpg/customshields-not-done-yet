package com.customshields;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Adds our resource pack to the "enabled packs" list in options.txt.
 * Runs before Minecraft reads options.txt, so no Minecraft classes are needed.
 */
final class OptionsEditor {
    private static final Pattern QUOTED = Pattern.compile("\"([^\"]*)\"");

    private OptionsEditor() {}

    /** @return true if the file was changed */
    static boolean enable(Path optionsFile, String packId) throws IOException {
        if (!Files.isRegularFile(optionsFile)) return false; // first launch: Minecraft hasn't made it yet

        List<String> lines = new ArrayList<>(Files.readAllLines(optionsFile, StandardCharsets.UTF_8));
        boolean changed = false;
        boolean found = false;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line.startsWith("resourcePacks:")) {
                found = true;
                List<String> packs = parse(line.substring("resourcePacks:".length()));
                if (!packs.contains(packId)) {
                    packs.add(packId); // last = highest priority
                    lines.set(i, "resourcePacks:" + format(packs));
                    changed = true;
                }
            } else if (line.startsWith("incompatibleResourcePacks:")) {
                List<String> packs = parse(line.substring("incompatibleResourcePacks:".length()));
                if (packs.remove(packId)) {
                    lines.set(i, "incompatibleResourcePacks:" + format(packs));
                    changed = true;
                }
            }
        }
        if (!found) {
            lines.add("resourcePacks:" + format(List.of(packId)));
            changed = true;
        }
        if (changed) Files.write(optionsFile, lines, StandardCharsets.UTF_8);
        return changed;
    }

    private static List<String> parse(String json) {
        List<String> out = new ArrayList<>();
        Matcher m = QUOTED.matcher(json);
        while (m.find()) out.add(m.group(1));
        return out;
    }

    private static String format(List<String> packs) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < packs.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append('"').append(packs.get(i)).append('"');
        }
        return sb.append(']').toString();
    }
}
