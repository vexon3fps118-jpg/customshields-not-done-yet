package com.customshields.client;

import com.customshields.ShieldManager;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.chat.Component;

public class CustomShieldsClient implements ClientModInitializer {
    private static volatile boolean openRequested = false;

    @Override
    public void onInitializeClient() {
        // /customshield              -> opens the gallery
        // /customshield save         -> saves your current shield (auto-named shield-1, shield-2, ...)
        // /customshield save <name>  -> saves it under a name you choose
        // (also works as /customsheild and /customshields)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            for (String name : new String[]{"customshield", "customsheild", "customshields"}) {
                dispatcher.register(ClientCommandManager.literal(name)
                        .executes(ctx -> {
                            openRequested = true; // open on the next tick, after the chat box has closed
                            return 1;
                        })
                        .then(ClientCommandManager.literal("save")
                                .executes(ctx -> save(ctx.getSource(), null))
                                .then(ClientCommandManager.argument("name", StringArgumentType.word())
                                        .executes(ctx -> save(ctx.getSource(),
                                                StringArgumentType.getString(ctx, "name"))))));
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openRequested) {
                openRequested = false;
                client.setScreen(new ShieldScreen(false));
            }
        });
    }

    private static int save(FabricClientCommandSource source, String name) {
        try {
            String saved = ShieldManager.saveCurrent(FabricLoader.getInstance().getGameDir(), name);
            source.sendFeedback(Component.literal("Saved your shield as \"" + saved
                    + "\". Open /customshield to pick it any time."));
            return 1;
        } catch (Exception e) {
            source.sendError(Component.literal(e.getMessage() == null ? e.toString() : e.getMessage()));
            return 0;
        }
    }
}
