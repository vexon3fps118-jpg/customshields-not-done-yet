package com.customshields.client;

import com.customshields.FilePickerMain;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Launches the native-looking file dialog in a separate Java process and returns the chosen file. */
final class FilePicker {
    private FilePicker() {}

    /** @param kind "image" or "video". Blocks until the dialog closes. @return chosen file, or null if cancelled. */
    static Path pick(String kind) throws IOException, InterruptedException {
        String java = ProcessHandle.current().info().command()
                .orElse(Path.of(System.getProperty("java.home"), "bin", "java").toString());
        Path jar = FabricLoader.getInstance().getModContainer("customshields")
                .orElseThrow(() -> new IOException("Mod container not found"))
                .getOrigin().getPaths().get(0);

        Process p = new ProcessBuilder(java, "-Djava.awt.headless=false", "-cp", jar.toString(),
                FilePickerMain.class.getName(), kind)
                .redirectError(ProcessBuilder.Redirect.DISCARD)
                .start();
        String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        p.waitFor();

        // take the last line that is a real file (ignores any JVM warnings printed before it)
        String[] lines = out.split("\\R");
        for (int i = lines.length - 1; i >= 0; i--) {
            String l = lines[i].trim();
            if (!l.isEmpty() && Files.isRegularFile(Path.of(l))) return Path.of(l);
        }
        return null;
    }
}
