package com.customshields.client;

import com.customshields.ShieldManager;
import com.customshields.ShieldPackBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * /customshield screen: a gallery of 16 coloured shields plus a "+" tile, and below it your saved shields.
 * "+" -> "Select PNG file" / "Select GIF / video" -> your computer's file picker.
 * Save your current design with the "Save current" button or /customshield save <name>.
 */
public class ShieldScreen extends Screen {
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "CustomShields-Worker");
        t.setDaemon(true);
        return t;
    });
    private static volatile String status = "";
    private static volatile boolean statusOk = true;

    private static final int COLS = 9;
    private static final int TILE_W = 32;
    private static final int TILE_H = 50;
    private static final int GAP = 2;
    private static final int CELL = 2;       // each face pixel is drawn 2x2 GUI pixels -> face is 24 x 44
    private static final int TILES = 17;      // 1 plus tile + 16 colours
    private static final int PER_PAGE = 9;    // saved shields shown at once

    private static int[][] colorFaces; // gallery previews of the 16 plain colours, built once

    private static int[][] colorFaces() {
        if (colorFaces == null) {
            int[][] f = new int[ShieldPackBuilder.DYE_RGB.length][];
            for (int i = 0; i < f.length; i++) f[i] = ShieldPackBuilder.solidPreview(ShieldPackBuilder.DYE_RGB[i]);
            colorFaces = f;
        }
        return colorFaces;
    }

    private final boolean addMode;
    private final int requestedPage;
    private final boolean deleteMode;

    private int gridX;
    private int gridY;
    private int savedY;
    private int page;
    private String selectedColor = "none";
    private List<String> saved = List.of();
    private final Map<String, int[]> thumbs = new HashMap<>();
    private final Map<String, String> savedColors = new HashMap<>();

    public ShieldScreen(boolean addMode) {
        this(addMode, 0, false);
    }

    public ShieldScreen(boolean addMode, int page, boolean deleteMode) {
        super(Component.literal(addMode ? "Add your own design" : "Custom Shields"));
        this.addMode = addMode;
        this.requestedPage = page;
        this.deleteMode = deleteMode;
    }

    private interface Job {
        void run() throws Exception;
    }

    private static Path game() {
        return FabricLoader.getInstance().getGameDir();
    }

    private static void say(String text, boolean ok) {
        status = text;
        statusOk = ok;
    }

    // ------------------------------------------------------------------ layout

    @Override
    protected void init() {
        int cx = this.width / 2;

        if (addMode) {
            int y = this.height / 2 - 34;
            this.addRenderableWidget(Button.builder(Component.literal("Select PNG file"),
                    b -> pickFile("image")).bounds(cx - 100, y, 200, 20).build());
            this.addRenderableWidget(Button.builder(Component.literal("Select GIF / video"),
                    b -> pickFile("video")).bounds(cx - 100, y + 26, 200, 20).build());
            this.addRenderableWidget(Button.builder(Component.literal("Back"),
                    b -> Minecraft.getInstance().setScreen(new ShieldScreen(false)))
                    .bounds(cx - 100, y + 64, 200, 20).build());
            return;
        }

        selectedColor = ShieldManager.currentColor(game());
        saved = ShieldManager.listSaved(game());
        thumbs.clear();
        savedColors.clear();
        for (String n : saved) {
            int[] t = ShieldManager.readThumb(game(), n);
            if (t != null) thumbs.put(n, t);
            savedColors.put(n, ShieldManager.savedColor(game(), n));
        }
        int pages = Math.max(1, (saved.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(requestedPage, pages - 1));

        int gridW = COLS * TILE_W + (COLS - 1) * GAP;
        gridX = cx - gridW / 2;
        gridY = 22;
        savedY = gridY + 2 * (TILE_H + GAP) + 14;

        for (int i = 0; i < TILES; i++) {
            final int idx = i;
            this.addRenderableWidget(Button.builder(Component.empty(), b -> onTile(idx))
                    .bounds(tileX(i), tileY(i), TILE_W, TILE_H).build());
        }

        int first = page * PER_PAGE;
        for (int k = 0; k < PER_PAGE && first + k < saved.size(); k++) {
            final String name = saved.get(first + k);
            this.addRenderableWidget(Button.builder(Component.empty(), b -> onSavedTile(name))
                    .bounds(savedX(k), savedY, TILE_W, TILE_H).build());
        }
        if (pages > 1) {
            this.addRenderableWidget(Button.builder(Component.literal("<"),
                    b -> Minecraft.getInstance().setScreen(new ShieldScreen(false, page - 1, deleteMode)))
                    .bounds(gridX - 24, savedY + 15, 20, 20).build());
            this.addRenderableWidget(Button.builder(Component.literal(">"),
                    b -> Minecraft.getInstance().setScreen(new ShieldScreen(false, page + 1, deleteMode)))
                    .bounds(gridX + gridW + 4, savedY + 15, 20, 20).build());
        }

        int bw = 92;
        int bx = cx - (4 * bw + 3 * 6) / 2;
        int by = this.height - 26;
        this.addRenderableWidget(Button.builder(Component.literal("Reset"),
                b -> reset()).bounds(bx, by, bw, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Save current"),
                b -> saveCurrent()).bounds(bx + (bw + 6), by, bw, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(deleteMode ? "Delete: ON" : "Delete: off"),
                b -> Minecraft.getInstance().setScreen(new ShieldScreen(false, page, !deleteMode)))
                .bounds(bx + 2 * (bw + 6), by, bw, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Done"),
                b -> this.onClose()).bounds(bx + 3 * (bw + 6), by, bw, 20).build());
    }

    private int tileX(int i) {
        return gridX + (i % COLS) * (TILE_W + GAP);
    }

    private int tileY(int i) {
        return gridY + (i / COLS) * (TILE_H + GAP);
    }

    private int savedX(int k) {
        return gridX + k * (TILE_W + GAP);
    }

    // ------------------------------------------------------------------ actions

    private void onTile(int idx) {
        if (idx == 0) {
            Minecraft.getInstance().setScreen(new ShieldScreen(true));
            return;
        }
        String name = ShieldPackBuilder.DYE_NAMES[idx - 1];
        selectedColor = name;
        run(() -> ShieldManager.setColor(game(), name), "Shield colour: " + pretty(name));
    }

    private void onSavedTile(String name) {
        if (deleteMode) {
            try {
                ShieldManager.deleteSaved(game(), name);
                say("Deleted \"" + name + "\".", true);
            } catch (Exception e) {
                say("Couldn't delete: " + msg(e), false);
            }
            Minecraft.getInstance().setScreen(new ShieldScreen(false, page, true));
            return;
        }
        selectedColor = savedColors.getOrDefault(name, "none");
        run(() -> ShieldManager.applySaved(game(), name), "Applied saved shield \"" + name + "\".");
    }

    private void saveCurrent() {
        try {
            String name = ShieldManager.saveCurrent(game(), null);
            say("Saved as \"" + name + "\". (Use /customshield save <name> to pick a name.)", true);
            int pages = (ShieldManager.listSaved(game()).size() + PER_PAGE - 1) / PER_PAGE;
            Minecraft.getInstance().setScreen(new ShieldScreen(false, Math.max(0, pages - 1), deleteMode));
        } catch (Exception e) {
            say(msg(e), false);
        }
    }

    private void reset() {
        selectedColor = "none";
        run(() -> ShieldManager.reset(game()), "Back to the normal shield.");
    }

    private void pickFile(String kind) {
        say("Opening file picker... (check your taskbar if you don't see it)", true);
        WORKER.submit(() -> {
            try {
                Path f = FilePicker.pick(kind);
                if (f == null) {
                    say("Cancelled.", true);
                    return;
                }
                say("Building shield from " + f.getFileName() + " ...", true);
                ShieldManager.importFile(game(), f);
                say("Applied " + f.getFileName() + ". Press Back, then \"Save current\" to keep it.", true);
                reloadTextures();
            } catch (Throwable t) {
                say("Couldn't open the file picker or read the file: " + msg(t)
                        + "  (You can also drop the file into the customshields folder.)", false);
            }
        });
    }

    private static void run(Job job, String okMessage) {
        say("Working...", true);
        WORKER.submit(() -> {
            try {
                job.run();
                say(okMessage, true);
                reloadTextures();
            } catch (Throwable t) {
                say("Error: " + msg(t), false);
            }
        });
    }

    private static void reloadTextures() {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.reloadResourcePacks());
    }

    private static String msg(Throwable t) {
        return t.getMessage() == null ? t.toString() : t.getMessage();
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta); // background + buttons

        centered(g, this.title.getString(), 10, 0xFFFFFFFF);

        if (addMode) {
            centered(g, "Pick an image (PNG/JPG) or an animation (GIF / MP4 / MOV / WEBM)", this.height / 2 - 56, 0xFFAAAAAA);
            drawStatus(g, this.height / 2 + 100);
            return;
        }

        String hover = null;

        // plus tile + 16 colours
        for (int i = 0; i < TILES; i++) {
            int x = tileX(i);
            int y = tileY(i);
            boolean sel = i > 0 && ShieldPackBuilder.DYE_NAMES[i - 1].equals(selectedColor);
            if (sel) {
                g.fill(x - 2, y - 2, x + TILE_W + 2, y + TILE_H + 2, 0xFFFFFFFF);
                g.fill(x, y, x + TILE_W, y + TILE_H, 0xFF3A3A3A);
            }
            int cx = x + TILE_W / 2;
            drawFrame(g, cx, y, -1);
            if (i == 0) {
                g.fill(cx - 12, y + 3, cx + 12, y + 47, 0xFF6B6B6B);
                g.fill(cx - 1, y + 14, cx + 1, y + 36, 0xFFFFFFFF);
                g.fill(cx - 8, y + 24, cx + 8, y + 26, 0xFFFFFFFF);
            } else {
                drawFace(g, cx, y, colorFaces()[i - 1]);
            }
            if (inside(mouseX, mouseY, x, y)) {
                hover = i == 0 ? "+  Add your own image / GIF / video" : pretty(ShieldPackBuilder.DYE_NAMES[i - 1]) + " shield";
            }
        }

        // saved shields
        int labelY = savedY - 12;
        int pages = Math.max(1, (saved.size() + PER_PAGE - 1) / PER_PAGE);
        String header = saved.isEmpty()
                ? "Saved shields: none yet. Pick a design, then press \"Save current\" or type /customshield save <name>"
                : "Saved shields (" + saved.size() + ")" + (pages > 1 ? "   page " + (page + 1) + "/" + pages : "");
        centered(g, header, labelY, 0xFFAAAAAA);

        int first = page * PER_PAGE;
        for (int k = 0; k < PER_PAGE && first + k < saved.size(); k++) {
            String name = saved.get(first + k);
            int x = savedX(k);
            int y = savedY;
            if (deleteMode) {
                g.fill(x - 1, y - 1, x + TILE_W + 1, y + TILE_H + 1, 0xFFE04040);
                g.fill(x, y, x + TILE_W, y + TILE_H, 0xFF3A3A3A);
            }
            int cx = x + TILE_W / 2;
            String c = savedColors.getOrDefault(name, "none");
            int idx = ShieldPackBuilder.dyeIndex(c);
            int rim = idx >= 0 ? ShieldPackBuilder.DYE_RGB[idx] : -1;
            drawFrame(g, cx, y, rim);
            int[] th = thumbs.get(name);
            if (th != null) {
                drawFace(g, cx, y, th);
            } else {
                g.fill(cx - 12, y + 3, cx + 12, y + 47, 0xFF6B6B6B); // no picture preview: a video, shown with a play icon
                g.fill(cx - 4, y + 19, cx - 2, y + 31, 0xFFFFFFFF);
                g.fill(cx - 2, y + 21, cx, y + 29, 0xFFFFFFFF);
                g.fill(cx, y + 23, cx + 2, y + 27, 0xFFFFFFFF);
            }
            if (inside(mouseX, mouseY, x, y)) {
                hover = deleteMode ? "Click to DELETE \"" + name + "\"" : name + "  (click to use)";
            }
        }

        int textY = savedY + TILE_H + 4;
        centered(g, hover != null ? hover
                : deleteMode ? "Delete mode: click a saved shield to remove it"
                : "Pick a colour, a saved shield, or + for your own picture", textY, 0xFFFFFFFF);

        String img = ShieldManager.currentImageName(game());
        centered(g, img == null ? "Current custom image: none" : "Current custom image: " + img, textY + 12, 0xFFAAAAAA);
        drawStatus(g, textY + 24);

        if (!ShieldManager.enabledAtLaunch) {
            centered(g, "First-time setup: restart Minecraft once so the shield pack switches on.", this.height - 40, 0xFFFFD34D);
        }
    }

    private static boolean inside(int mx, int my, int x, int y) {
        return mx >= x && mx < x + TILE_W && my >= y && my < y + TILE_H;
    }

    private void drawStatus(GuiGraphics g, int y) {
        if (!status.isEmpty()) centered(g, status, y, statusOk ? 0xFF8CE08C : 0xFFFF7A7A);
    }

    private void centered(GuiGraphics g, String text, int y, int argb) {
        g.drawString(this.font, text, this.width / 2 - this.font.width(text) / 2, y, argb, true);
    }

    /** Dark outline around the shield face; rim is the shield colour (or -1 for none). */
    private static void drawFrame(GuiGraphics g, int cx, int y, int rimRgb) {
        g.fill(cx - 14, y + 1, cx + 14, y + 49, 0xFF101010);
        g.fill(cx - 13, y + 2, cx + 13, y + 48, rimRgb >= 0 ? 0xFF000000 | rimRgb : 0xFF3A3A3A);
    }

    /**
     * Draws the real 12x22 shield face (the same pixels the game uses), 2x2 GUI pixels each.
     * Runs of the same colour are merged into one rectangle to keep it cheap.
     */
    private static void drawFace(GuiGraphics g, int cx, int y, int[] px) {
        int w = ShieldPackBuilder.FACE_W;
        int h = ShieldPackBuilder.FACE_H;
        int ox = cx - w * CELL / 2;
        int oy = y + 3;
        for (int ty = 0; ty < h; ty++) {
            int tx = 0;
            while (tx < w) {
                int argb = px[ty * w + tx];
                int end = tx + 1;
                while (end < w && px[ty * w + end] == argb) end++;
                if (((argb >>> 24) & 255) >= 128) {
                    g.fill(ox + tx * CELL, oy + ty * CELL, ox + end * CELL, oy + (ty + 1) * CELL,
                            0xFF000000 | (argb & 0xFFFFFF));
                }
                tx = end;
            }
        }
    }

    private static String pretty(String name) {
        if (name == null || name.equals("none")) return "Normal";
        String s = name.replace('_', ' ');
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
