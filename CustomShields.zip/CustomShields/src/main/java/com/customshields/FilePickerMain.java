package com.customshields;

import javax.swing.JFileChooser;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;

/**
 * Runs in its OWN Java process (launched by the mod) so the file dialog can't clash with
 * Minecraft's window. Prints the chosen path to stdout, or nothing if cancelled.
 * Uses only the JDK, no Minecraft classes.
 */
public final class FilePickerMain {
    public static void main(String[] args) {
        String kind = args.length > 0 ? args[0] : "image";
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        JFileChooser chooser = new JFileChooser();
        File pictures = new File(System.getProperty("user.home"), kind.equals("image") ? "Pictures" : "Videos");
        chooser.setCurrentDirectory(pictures.isDirectory() ? pictures : new File(System.getProperty("user.home")));
        if (kind.equals("image")) {
            chooser.setDialogTitle("Select a PNG for your shield");
            chooser.setFileFilter(new FileNameExtensionFilter("Images (png, jpg, bmp)", "png", "jpg", "jpeg", "bmp"));
        } else {
            chooser.setDialogTitle("Select a GIF or video for your shield");
            chooser.setFileFilter(new FileNameExtensionFilter("GIF / video (gif, mp4, mov, webm, mkv, avi)",
                    "gif", "mp4", "mov", "webm", "mkv", "avi"));
        }
        chooser.setAcceptAllFileFilterUsed(false);
        if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            System.out.println(chooser.getSelectedFile().getAbsolutePath());
        }
        System.exit(0);
    }
}
