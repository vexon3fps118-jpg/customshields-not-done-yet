package com.customshields;

import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Runs before Minecraft starts: builds the shield pack from the customshields folder and
 * switches it on in options.txt, then watches the folder for changes.
 * (The in-game /customshield screen lives in the client entrypoint.)
 */
public class CustomShieldsPreLaunch implements PreLaunchEntrypoint {

    @Override
    public void onPreLaunch() {
        try {
            if (FabricLoader.getInstance().getEnvironmentType() != EnvType.CLIENT) return;
            Path game = FabricLoader.getInstance().getGameDir();

            ShieldManager.rebuild(game);
            start(game);

            Thread t = new Thread(() -> watch(game), "CustomShields-Watcher");
            t.setDaemon(true);
            t.start();
        } catch (Throwable e) {
            log("Startup failed (game will still launch normally): " + e);
        }
    }

    /** Package-private so tests can run it without a real game. */
    static void start(Path game) throws Exception {
        ShieldPackBuilder.Settings st = ShieldPackBuilder.Settings.load(ShieldManager.settingsFile(game));
        Path options = ShieldManager.optionsFile(game);
        if (st.autoEnable) {
            if (OptionsEditor.enable(options, ShieldManager.PACK_ID)) log("Enabled the CustomShields resource pack.");
        }
        boolean listed = Files.isRegularFile(options) && st.autoEnable;
        ShieldManager.enabledAtLaunch = listed;
        if (!Files.isRegularFile(options)) {
            log("First launch: restart the game once after choosing a design (or enable 'CustomShields' under Options > Resource Packs).");
        }
        String img = ShieldManager.currentImageName(game);
        log(img == null ? "No image yet. Use /customshield in-game, or drop a file in " + ShieldManager.inputDir(game)
                : "Using " + img);
    }

    private static void watch(Path game) {
        while (true) {
            try {
                Thread.sleep(2000);
                // Only react to changes the mod didn't make itself (e.g. you dropped a new file in the folder).
                if (!ShieldManager.signature(game).equals(ShieldManager.lastBuilt())) {
                    Thread.sleep(1000); // let big copies finish
                    ShieldManager.rebuild(game);
                    log("Updated from folder. Press F3+T in-game to reload textures.");
                }
            } catch (InterruptedException e) {
                return;
            } catch (Throwable ignored) {
                // keep watching
            }
        }
    }

    static void log(String msg) {
        System.out.println("[CustomShields] " + msg);
    }
}
