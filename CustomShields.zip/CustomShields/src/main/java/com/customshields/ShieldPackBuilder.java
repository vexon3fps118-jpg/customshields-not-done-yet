package com.customshields;

import org.w3c.dom.Node;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.stream.ImageInputStream;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

/**
 * Turns an image / GIF / video into a resource pack that replaces the plain
 * shield texture. Pure Java: no Minecraft classes, so it works on any 1.21+.
 *
 * Vanilla shield texture is a 64x64 sheet. The shield model is a 12x22x1 box
 * at texOffs(0,0), so the UV layout is:
 *   front  x 1..13  y 1..23      back   x 14..26 y 1..23
 *   top    x 1..13  y 0..1       bottom x 13..25 y 0..1
 *   left   x 0..1   y 1..23      right  x 13..14 y 1..23
 *   handle x 26..40 y 0..12
 * We scale the sheet up and paste the artwork onto the front rectangle.
 */
public final class ShieldPackBuilder {
    public static final String PACK_NAME = "CustomShields";
    public static final String MARKER = ".customshields";

    private static final int SHEET = 64;
    private static final int[] FRONT = {1, 1, 13, 23};
    private static final int[] BACK = {14, 1, 26, 23};
    private static final int[] TOP = {1, 0, 13, 1};
    private static final int[] BOTTOM = {13, 0, 25, 1};
    private static final int[] LEFT = {0, 1, 1, 23};
    private static final int[] RIGHT = {13, 1, 14, 23};
    private static final int[] HANDLE = {26, 0, 40, 12};

    private static final int WOOD = 0xFF6E5430;
    private static final int HANDLE_COL = 0xFF3C2C18;
    private static final int MAX_TEX = 16384;

    public static final String[] DYE_NAMES = {"white", "orange", "magenta", "light_blue", "yellow", "lime",
            "pink", "gray", "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"};
    public static final int[] DYE_RGB = {0xF9FFFE, 0xF9801D, 0xC74EBD, 0x3AB3DA, 0xFED83D, 0x80C71F,
            0xF38BAA, 0x474F52, 0x9D9D97, 0x169C9C, 0x8932B8, 0x3C44AA, 0x835432, 0x5E7C16, 0xB02E26, 0x1D1D21};

    private ShieldPackBuilder() {}

    public static int dyeIndex(String name) {
        for (int i = 0; i < DYE_NAMES.length; i++) if (DYE_NAMES[i].equals(name)) return i;
        return -1;
    }

    private static int shade(int rgb, double f) {
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * f));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * f));
        int b = Math.min(255, (int) ((rgb & 255) * f));
        return 0xFF000000 | r << 16 | g << 8 | b;
    }

    // ------------------------------------------------------------------ settings

    public static final class Settings {
        public String fit = "cover";     // cover | contain | stretch
        public int fps = 10;             // videos only
        public int scale = 0;            // 0 = auto (8 stills, 4 animations)
        public int maxFrames = 20;
        public double seconds = 0;       // 0 = whole video
        public String ffmpeg = "ffmpeg";
        public boolean autoEnable = true;
        public String color = "none";   // none or a dye name

        public static Settings load(Path file) {
            Settings s = new Settings();
            if (!Files.isRegularFile(file)) return s;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(file)) {
                p.load(in);
            } catch (IOException e) {
                return s;
            }
            s.fit = p.getProperty("fit", s.fit).trim().toLowerCase(Locale.ROOT);
            s.fps = intOr(p.getProperty("fps"), s.fps);
            s.scale = intOr(p.getProperty("scale"), s.scale);
            s.maxFrames = Math.max(1, intOr(p.getProperty("maxFrames"), s.maxFrames));
            try {
                s.seconds = Double.parseDouble(p.getProperty("seconds", "0").trim());
            } catch (NumberFormatException ignored) {}
            s.ffmpeg = p.getProperty("ffmpeg", s.ffmpeg).trim();
            s.autoEnable = !"false".equalsIgnoreCase(p.getProperty("autoEnable", "true").trim());
            String c = p.getProperty("color", "none").trim().toLowerCase(Locale.ROOT);
            s.color = (c.equals("none") || dyeIndex(c) >= 0) ? c : "none";
            if (s.fps < 1) s.fps = 10;
            return s;
        }

        public static void writeDefaults(Path file) throws IOException {
            String txt = String.join("\n",
                    "# Custom Shields settings. Edit, then restart the game (or press F3+T if the game is running).",
                    "",
                    "# cover   = fill the whole shield face, cropping the edges of your image",
                    "# contain = show the whole image, leaving transparent bars",
                    "# stretch = squash the image to fit exactly",
                    "fit=cover",
                    "",
                    "# Videos only: frames per second to sample, max length in seconds (0 = whole clip)",
                    "fps=10",
                    "seconds=0",
                    "",
                    "# Max animation frames (more frames = bigger texture)",
                    "maxFrames=20",
                    "",
                    "# Texture sharpness multiplier over vanilla 64px. 0 = auto (8 for stills, 4 for animations)",
                    "scale=0",
                    "",
                    "# Path to ffmpeg (only needed for video files that are not on your PATH)",
                    "ffmpeg=ffmpeg",
                    "",
                    "# Shield colour: none, white, orange, magenta, light_blue, yellow, lime, pink, gray,",
                    "# light_gray, cyan, purple, blue, brown, green, red, black",
                    "color=none",
                    "",
                    "# Automatically turn the CustomShields resource pack on at launch",
                    "autoEnable=true",
                    "");
            Files.writeString(file, txt, StandardCharsets.UTF_8);
        }

        /** Set or add one key in a properties file, keeping comments. */
        public static void set(Path file, String key, String value) throws IOException {
            List<String> lines = Files.isRegularFile(file)
                    ? new ArrayList<>(Files.readAllLines(file, StandardCharsets.UTF_8)) : new ArrayList<>();
            boolean done = false;
            for (int i = 0; i < lines.size(); i++) {
                if (lines.get(i).startsWith(key + "=")) {
                    lines.set(i, key + "=" + value);
                    done = true;
                }
            }
            if (!done) lines.add(key + "=" + value);
            Files.write(file, lines, StandardCharsets.UTF_8);
        }

        private static int intOr(String v, int d) {
            try {
                return v == null ? d : Integer.parseInt(v.trim());
            } catch (NumberFormatException e) {
                return d;
            }
        }
    }

    private record Frames(List<BufferedImage> images, int ticks) {}

    // ------------------------------------------------------------------ build

    /** input may be null: then a plain coloured shield is built (or an empty pack if no colour). */
    public static void build(Path input, Path packDir, Settings st) throws Exception {
        int ci = dyeIndex(st.color);
        if (input == null && ci < 0) {
            writeEmptyPack(packDir);
            return;
        }
        int tint = ci >= 0 ? DYE_RGB[ci] : -1;
        Frames fr = input != null ? load(input, st) : new Frames(List.of(solidArt(DYE_RGB[ci])), 1);
        int n = fr.images().size();
        boolean anim = n > 1;

        int s = st.scale > 0 ? st.scale : (anim ? 4 : 8);
        s = Math.max(1, Math.min(s, 32));
        s = Math.min(s, Math.max(1, MAX_TEX / (SHEET * n)));
        s = Math.min(s, MAX_TEX / SHEET);

        BufferedImage strip = new BufferedImage(SHEET * s, SHEET * s * n, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = strip.createGraphics();
        int fw = (FRONT[2] - FRONT[0]) * s;
        int fh = (FRONT[3] - FRONT[1]) * s;
        for (int i = 0; i < n; i++) {
            BufferedImage face = fitFace(fr.images().get(i), fw, fh, st.fit);
            g.drawImage(buildSheet(face, s, tint), 0, i * SHEET * s, null);
        }
        g.dispose();

        Path texDir = packDir.resolve("assets").resolve("minecraft").resolve("textures").resolve("entity");
        Files.createDirectories(texDir);
        ImageIO.write(strip, "png", texDir.resolve("shield_base_nopattern.png").toFile());

        Path meta = texDir.resolve("shield_base_nopattern.png.mcmeta");
        if (anim) {
            Files.writeString(meta,
                    "{\"animation\":{\"frametime\":" + fr.ticks() + "}}", StandardCharsets.UTF_8);
        } else {
            Files.deleteIfExists(meta);
        }

        writeMcmeta(packDir);

        BufferedImage icon = fitFace(fr.images().get(0), 128, 128, "cover");
        ImageIO.write(icon, "png", packDir.resolve("pack.png").toFile());
        Files.writeString(packDir.resolve(MARKER), "generated", StandardCharsets.UTF_8);
    }

    private static void writeMcmeta(Path packDir) throws IOException {
        Files.createDirectories(packDir);
        // pack_format + supported_formats for 1.20.2-1.21.8, min/max_format for 1.21.9+
        Files.writeString(packDir.resolve("pack.mcmeta"),
                "{\"pack\":{\"pack_format\":64,"
                        + "\"supported_formats\":{\"min_inclusive\":15,\"max_inclusive\":999},"
                        + "\"min_format\":15,\"max_format\":999,"
                        + "\"description\":\"Custom shield (auto-generated by Custom Shields mod)\"}}",
                StandardCharsets.UTF_8);
        Files.writeString(packDir.resolve(MARKER), "generated", StandardCharsets.UTF_8);
    }

    /** A valid pack with no textures: the vanilla shield shows through. Kept on disk so it stays enabled. */
    public static void writeEmptyPack(Path packDir) throws IOException {
        Path texDir = packDir.resolve("assets").resolve("minecraft").resolve("textures").resolve("entity");
        Files.deleteIfExists(texDir.resolve("shield_base_nopattern.png"));
        Files.deleteIfExists(texDir.resolve("shield_base_nopattern.png.mcmeta"));
        Files.deleteIfExists(packDir.resolve("pack.png"));
        writeMcmeta(packDir);
    }

    private static BufferedImage solidArt(int rgb) {
        int w = 120, h = 220, b = 10;
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setColor(new java.awt.Color(shade(rgb, 0.7), true));
        g.fillRect(0, 0, w, h);
        g.setColor(new java.awt.Color(shade(rgb, 1.0), true));
        g.fillRect(b, b, w - 2 * b, h - 2 * b);
        g.setColor(new java.awt.Color(0xFFD0D0D0, true));
        g.fillOval(w / 2 - 14, h / 2 - 14, 28, 28);
        g.dispose();
        return img;
    }

    public static final int FACE_W = FRONT[2] - FRONT[0]; // 12
    public static final int FACE_H = FRONT[3] - FRONT[1]; // 22

    /** The shield face exactly as it will be drawn in game, shrunk to 12x22 ARGB pixels (for the gallery). */
    public static int[] previewFace(BufferedImage art, String fit) {
        BufferedImage face = fitFace(art, FACE_W, FACE_H, fit);
        return face.getRGB(0, 0, FACE_W, FACE_H, null, 0, FACE_W);
    }

    /** Preview of the plain coloured shield (same artwork the colour-only shield uses in game). */
    public static int[] solidPreview(int rgb) {
        return previewFace(solidArt(rgb), "stretch");
    }

    /** Write a 12x22 face preview of an image / first GIF frame. Throws if it can't be read (e.g. video). */
    public static void writeThumb(Path input, Path out, String fit) throws IOException {
        BufferedImage img = ImageIO.read(input.toFile());
        if (img == null) throw new IOException("No thumbnail available for " + input.getFileName());
        ImageIO.write(fitFace(img, FACE_W, FACE_H, fit), "png", out.toFile());
    }

    public static void deletePack(Path packDir) throws IOException {
        if (!Files.isDirectory(packDir) || !Files.exists(packDir.resolve(MARKER))) return; // never delete foreign folders
        try (Stream<Path> w = Files.walk(packDir)) {
            w.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
        }
    }

    // ------------------------------------------------------------------ sheet layout

    private static BufferedImage buildSheet(BufferedImage face, int s, int tint) {
        BufferedImage sheet = new BufferedImage(SHEET * s, SHEET * s, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = sheet.createGraphics();
        fill(g, BACK, s, tint >= 0 ? shade(tint, 0.85) : WOOD);
        fill(g, HANDLE, s, tint >= 0 ? shade(tint, 0.5) : HANDLE_COL);
        g.drawImage(face, FRONT[0] * s, FRONT[1] * s, null);
        g.dispose();

        int w = face.getWidth(), h = face.getHeight();
        edge(sheet, TOP, s, face, 0, 0, w, 1, tint);
        edge(sheet, BOTTOM, s, face, 0, h - 1, w, 1, tint);
        edge(sheet, LEFT, s, face, 0, 0, 1, h, tint);
        edge(sheet, RIGHT, s, face, w - 1, 0, 1, h, tint);
        return sheet;
    }

    private static void fill(Graphics2D g, int[] r, int s, int argb) {
        g.setColor(new java.awt.Color(argb, true));
        g.fillRect(r[0] * s, r[1] * s, (r[2] - r[0]) * s, (r[3] - r[1]) * s);
    }

    /** Stretch a 1px border strip of the artwork across a side edge, slightly darkened. */
    private static void edge(BufferedImage sheet, int[] r, int s, BufferedImage face,
                             int sx, int sy, int sw, int sh, int tint) {
        int x0 = r[0] * s, y0 = r[1] * s;
        int dw = (r[2] - r[0]) * s, dh = (r[3] - r[1]) * s;
        for (int dy = 0; dy < dh; dy++) {
            for (int dx = 0; dx < dw; dx++) {
                if (tint >= 0) {
                    sheet.setRGB(x0 + dx, y0 + dy, shade(tint, 0.7));
                    continue;
                }
                int px = face.getRGB(sx + dx * sw / dw, sy + dy * sh / dh);
                if (((px >>> 24) & 255) < 128) px = WOOD;
                int rr = (int) (((px >> 16) & 255) * 0.8);
                int gg = (int) (((px >> 8) & 255) * 0.8);
                int bb = (int) ((px & 255) * 0.8);
                sheet.setRGB(x0 + dx, y0 + dy, 0xFF000000 | rr << 16 | gg << 8 | bb);
            }
        }
    }

    // ------------------------------------------------------------------ scaling

    private static BufferedImage fitFace(BufferedImage src, int w, int h, String mode) {
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        int iw = src.getWidth(), ih = src.getHeight();
        int nw, nh;
        if ("stretch".equals(mode)) {
            nw = w;
            nh = h;
        } else {
            double k = "contain".equals(mode)
                    ? Math.min(w / (double) iw, h / (double) ih)
                    : Math.max(w / (double) iw, h / (double) ih);
            nw = Math.max(1, (int) Math.round(iw * k));
            nh = Math.max(1, (int) Math.round(ih * k));
        }
        BufferedImage scaled = resize(src, nw, nh);
        Graphics2D g = out.createGraphics();
        g.drawImage(scaled, (w - nw) / 2, (h - nh) / 2, null);
        g.dispose();
        return out;
    }

    /** Step-down halving gives much cleaner results than one big bicubic jump. */
    private static BufferedImage resize(BufferedImage img, int w, int h) {
        BufferedImage cur = draw(img, img.getWidth(), img.getHeight());
        while (cur.getWidth() / 2 >= w && cur.getHeight() / 2 >= h) {
            cur = draw(cur, cur.getWidth() / 2, cur.getHeight() / 2);
        }
        return draw(cur, w, h);
    }

    private static BufferedImage draw(BufferedImage src, int w, int h) {
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setComposite(AlphaComposite.Src);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawImage(src, 0, 0, w, h, null);
        g.dispose();
        return out;
    }

    // ------------------------------------------------------------------ input loading

    private static Frames load(Path input, Settings st) throws Exception {
        String name = input.getFileName().toString().toLowerCase(Locale.ROOT);
        String ext = name.substring(name.lastIndexOf('.') + 1);
        switch (ext) {
            case "png", "jpg", "jpeg", "bmp" -> {
                BufferedImage img = ImageIO.read(input.toFile());
                if (img == null) throw new IOException("Could not read image: " + input.getFileName());
                return new Frames(List.of(img), 1);
            }
            case "gif" -> {
                return loadGif(input, st);
            }
            default -> {
                return loadVideo(input, st);
            }
        }
    }

    private static Frames loadGif(Path input, Settings st) throws IOException {
        Iterator<ImageReader> it = ImageIO.getImageReadersByFormatName("gif");
        if (!it.hasNext()) throw new IOException("No GIF reader available");
        ImageReader reader = it.next();
        List<BufferedImage> frames = new ArrayList<>();
        int ticks = 0;
        try (ImageInputStream in = ImageIO.createImageInputStream(input.toFile())) {
            reader.setInput(in, false);
            int count = reader.getNumImages(true);

            int cw = 0, ch = 0;
            IIOMetadata sm = reader.getStreamMetadata();
            if (sm != null) {
                Node sroot = sm.getAsTree("javax_imageio_gif_stream_1.0");
                cw = parse(attr(sroot, "LogicalScreenDescriptor", "logicalScreenWidth"));
                ch = parse(attr(sroot, "LogicalScreenDescriptor", "logicalScreenHeight"));
            }
            if (cw <= 0 || ch <= 0) {
                BufferedImage first = reader.read(0);
                cw = first.getWidth();
                ch = first.getHeight();
            }

            BufferedImage canvas = new BufferedImage(cw, ch, BufferedImage.TYPE_INT_ARGB);
            for (int i = 0; i < count; i++) {
                BufferedImage fr = reader.read(i);
                Node root = reader.getImageMetadata(i).getAsTree("javax_imageio_gif_image_1.0");
                int left = parse(attr(root, "ImageDescriptor", "imageLeftPosition"));
                int top = parse(attr(root, "ImageDescriptor", "imageTopPosition"));
                String disposal = attr(root, "GraphicControlExtension", "disposalMethod");
                int delay = parse(attr(root, "GraphicControlExtension", "delayTime"));
                if (ticks == 0 && delay > 0) ticks = Math.max(1, Math.round(delay * 10f / 50f));

                Graphics2D g = canvas.createGraphics();
                g.drawImage(fr, left, top, null);
                g.dispose();

                BufferedImage snap = new BufferedImage(cw, ch, BufferedImage.TYPE_INT_ARGB);
                Graphics2D sg = snap.createGraphics();
                sg.drawImage(canvas, 0, 0, null);
                sg.dispose();
                frames.add(snap);

                if ("restoreToBackgroundColor".equals(disposal)) {
                    Graphics2D cg = canvas.createGraphics();
                    cg.setComposite(AlphaComposite.Clear);
                    cg.fillRect(left, top, fr.getWidth(), fr.getHeight());
                    cg.dispose();
                }
            }
        } finally {
            reader.dispose();
        }
        if (frames.isEmpty()) throw new IOException("GIF has no frames");
        frames = thin(frames, st.maxFrames);
        return new Frames(frames, ticks > 0 ? ticks : 5);
    }

    private static Frames loadVideo(Path input, Settings st) throws Exception {
        Path tmp = Files.createTempDirectory("customshields");
        try {
            List<String> cmd = new ArrayList<>(List.of(st.ffmpeg, "-y", "-loglevel", "error",
                    "-i", input.toString(), "-vf", "fps=" + st.fps));
            if (st.seconds > 0) {
                cmd.add("-t");
                cmd.add(String.valueOf(st.seconds));
            }
            cmd.add("-frames:v");
            cmd.add(String.valueOf(st.maxFrames));
            cmd.add(tmp.resolve("f_%04d.png").toString());

            Process p;
            try {
                p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            } catch (IOException e) {
                throw new IOException("Video needs ffmpeg, which was not found. Install ffmpeg, set its path in "
                        + "settings.properties, or convert the video to a GIF.", e);
            }
            ByteArrayOutputStream log = new ByteArrayOutputStream();
            p.getInputStream().transferTo(log);
            if (!p.waitFor(180, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                throw new IOException("ffmpeg timed out");
            }

            List<Path> files;
            try (Stream<Path> l = Files.list(tmp)) {
                files = l.filter(f -> f.getFileName().toString().endsWith(".png")).sorted().toList();
            }
            if (files.isEmpty()) throw new IOException("ffmpeg produced no frames: " + log.toString(StandardCharsets.UTF_8));
            List<BufferedImage> frames = new ArrayList<>();
            for (Path f : files) frames.add(ImageIO.read(f.toFile()));
            return new Frames(frames, Math.max(1, Math.round(20f / st.fps)));
        } finally {
            try (Stream<Path> w = Files.walk(tmp)) {
                w.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
            }
        }
    }

    private static List<BufferedImage> thin(List<BufferedImage> in, int max) {
        if (in.size() <= max) return in;
        List<BufferedImage> out = new ArrayList<>();
        double step = in.size() / (double) max;
        for (int i = 0; i < max; i++) out.add(in.get((int) (i * step)));
        return out;
    }

    private static String attr(Node n, String name, String a) {
        if (n.getNodeName().equals(name)) {
            Node at = n.getAttributes().getNamedItem(a);
            return at == null ? null : at.getNodeValue();
        }
        for (Node c = n.getFirstChild(); c != null; c = c.getNextSibling()) {
            String v = attr(c, name, a);
            if (v != null) return v;
        }
        return null;
    }

    private static int parse(String v) {
        try {
            return v == null ? 0 : Integer.parseInt(v.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ------------------------------------------------------------------ standalone CLI (handy for testing without Minecraft)

    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.out.println("usage: java -cp customshields.jar com.customshields.ShieldPackBuilder <image|gif|video> <outputPackFolder>");
            return;
        }
        build(Path.of(args[0]), Path.of(args[1]), new Settings());
        System.out.println("Pack written to " + args[1]);
    }
}
