package com.customshields;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Stream;

/** Everything the mod does to files. No Minecraft classes, so it is unit-testable. */
public final class ShieldManager {
    public static final String DIR = "customshields";
    public static final String PACK_ID = "file/" + ShieldPackBuilder.PACK_NAME;
    private static final Set<String> EXT = Set.of("png", "jpg", "jpeg", "bmp", "gif",
            "mp4", "mov", "webm", "mkv", "avi");

    /** Set at startup: false means the pack isn't switched on yet, so a restart is needed once. */
    public static volatile boolean enabledAtLaunch = true;

    private static volatile String lastBuilt = "";
    public static String lastBuilt() { return lastBuilt; }

    private ShieldManager() {}

    public static Path inputDir(Path game) { return game.resolve(DIR); }
    public static Path settingsFile(Path game) { return inputDir(game).resolve("settings.properties"); }
    public static Path packDir(Path game) { return game.resolve("resourcepacks").resolve(ShieldPackBuilder.PACK_NAME); }
    public static Path optionsFile(Path game) { return game.resolve("options.txt"); }

    public static Path findInput(Path game) throws IOException {
        Path dir = inputDir(game);
        if (!Files.isDirectory(dir)) return null;
        try (Stream<Path> s = Files.list(dir)) {
            return s.filter(Files::isRegularFile)
                    .filter(p -> EXT.contains(ext(p)))
                    .max(Comparator.comparingLong(p -> p.toFile().lastModified()))
                    .orElse(null);
        }
    }

    /** Build (or rebuild) the pack from whatever is in the folder + settings. Always leaves a valid pack on disk. */
    public static synchronized void rebuild(Path game) throws Exception {
        Files.createDirectories(inputDir(game));
        if (!Files.exists(settingsFile(game))) ShieldPackBuilder.Settings.writeDefaults(settingsFile(game));
        ShieldPackBuilder.Settings st = ShieldPackBuilder.Settings.load(settingsFile(game));
        Files.createDirectories(packDir(game).getParent());
        ShieldPackBuilder.build(findInput(game), packDir(game), st);
        lastBuilt = signature(game);
    }

    /** Copy a picked file into the folder as custom.<ext> and rebuild. */
    public static synchronized void importFile(Path game, Path src) throws Exception {
        if (!EXT.contains(ext(src))) throw new IOException("Unsupported file type: " + src.getFileName());
        Files.createDirectories(inputDir(game));
        removeCustomFiles(game);
        Path dest = inputDir(game).resolve("custom." + ext(src));
        Files.copy(src, dest, StandardCopyOption.REPLACE_EXISTING);
        dest.toFile().setLastModified(System.currentTimeMillis());
        rebuild(game);
    }

    public static synchronized void setColor(Path game, String color) throws Exception {
        Files.createDirectories(inputDir(game));
        if (!Files.exists(settingsFile(game))) ShieldPackBuilder.Settings.writeDefaults(settingsFile(game));
        ShieldPackBuilder.Settings.set(settingsFile(game), "color", color);
        rebuild(game);
    }

    /** Remove images the GUI imported and clear the colour. Files you dropped in by hand are kept. */
    public static synchronized void reset(Path game) throws Exception {
        removeCustomFiles(game);
        if (Files.exists(settingsFile(game))) ShieldPackBuilder.Settings.set(settingsFile(game), "color", "none");
        rebuild(game);
    }

    public static String currentColor(Path game) {
        return ShieldPackBuilder.Settings.load(settingsFile(game)).color;
    }

    public static String currentImageName(Path game) {
        try {
            Path p = findInput(game);
            return p == null ? null : p.getFileName().toString();
        } catch (IOException e) {
            return null;
        }
    }

    public static String signature(Path game) throws IOException {
        Path in = findInput(game);
        String s = Files.exists(settingsFile(game)) ? String.valueOf(settingsFile(game).toFile().lastModified()) : "0";
        return (in == null ? "none" : in + "|" + in.toFile().lastModified() + "|" + in.toFile().length()) + "|" + s;
    }

    // ------------------------------------------------------------------ saved shields

    public static final int MAX_SAVED = 18;
    public static final int THUMB_W = ShieldPackBuilder.FACE_W;
    public static final int THUMB_H = ShieldPackBuilder.FACE_H;

    public static Path savedDir(Path game) { return inputDir(game).resolve("saved"); }

    /** lowercase letters, digits, - and _ only, max 24 chars. Returns "" if nothing usable is left. */
    public static String cleanName(String raw) {
        if (raw == null) return "";
        String n = raw.trim().toLowerCase(Locale.ROOT).replace(' ', '-').replaceAll("[^a-z0-9_-]", "");
        return n.length() > 24 ? n.substring(0, 24) : n;
    }

    public static synchronized List<String> listSaved(Path game) {
        List<String> out = new ArrayList<>();
        Path dir = savedDir(game);
        if (!Files.isDirectory(dir)) return out;
        try (Stream<Path> s = Files.list(dir)) {
            for (Path d : s.filter(Files::isDirectory).sorted().toList()) {
                if (savedImage(d) != null) out.add(d.getFileName().toString());
            }
        } catch (IOException ignored) {}
        return out;
    }

    /**
     * Save the shield you currently have (custom image + colour) so it can be re-applied from the gallery.
     * @param requested name, or null/blank for an automatic "shield-N"
     * @return the name it was saved under
     */
    public static synchronized String saveCurrent(Path game, String requested) throws IOException {
        Path in = findInput(game);
        if (in == null) {
            throw new IOException("Nothing to save yet - use /customshield and pick a PNG, GIF or video first.");
        }
        List<String> existing = listSaved(game);
        String name;
        if (requested == null || requested.isBlank()) {
            int i = 1;
            while (existing.contains("shield-" + i)) i++;
            name = "shield-" + i;
        } else {
            name = cleanName(requested);
            if (name.isEmpty()) throw new IOException("Names can use letters, numbers, - and _ only.");
        }
        if (!existing.contains(name) && existing.size() >= MAX_SAVED) {
            throw new IOException("You can keep up to " + MAX_SAVED + " saved shields - delete one in the gallery first.");
        }

        Path dir = savedDir(game).resolve(name);
        Files.createDirectories(dir);
        clearDir(dir);
        Path img = dir.resolve("image." + ext(in));
        Files.copy(in, img, StandardCopyOption.REPLACE_EXISTING);

        String color = ShieldPackBuilder.Settings.load(settingsFile(game)).color;
        Files.writeString(dir.resolve("meta.properties"), "color=" + color + "\n", StandardCharsets.UTF_8);
        try {
            ShieldPackBuilder.writeThumb(img, dir.resolve("thumb.png"),
                    ShieldPackBuilder.Settings.load(settingsFile(game)).fit);
        } catch (Exception e) {
            Files.deleteIfExists(dir.resolve("thumb.png")); // videos: gallery just shows a plain shield
        }
        return name;
    }

    /** Re-apply a saved shield: its image + colour, then rebuild the pack. */
    public static synchronized void applySaved(Path game, String name) throws Exception {
        Path dir = savedDirFor(game, name);
        Path img = savedImage(dir);
        if (img == null) throw new IOException("Saved shield \"" + name + "\" not found.");
        Files.createDirectories(inputDir(game));
        if (!Files.exists(settingsFile(game))) ShieldPackBuilder.Settings.writeDefaults(settingsFile(game));
        removeCustomFiles(game);
        Path dest = inputDir(game).resolve("custom." + ext(img));
        Files.copy(img, dest, StandardCopyOption.REPLACE_EXISTING);
        dest.toFile().setLastModified(System.currentTimeMillis());
        ShieldPackBuilder.Settings.set(settingsFile(game), "color", savedColor(game, name));
        rebuild(game);
    }

    public static synchronized void deleteSaved(Path game, String name) throws IOException {
        Path dir = savedDirFor(game, name);
        if (!Files.isDirectory(dir)) return;
        try (Stream<Path> w = Files.walk(dir)) {
            w.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
        }
    }

    public static String savedColor(Path game, String name) {
        try {
            Path meta = savedDirFor(game, name).resolve("meta.properties");
            if (!Files.isRegularFile(meta)) return "none";
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(meta)) {
                p.load(in);
            }
            String c = p.getProperty("color", "none").trim();
            return (c.equals("none") || ShieldPackBuilder.dyeIndex(c) >= 0) ? c : "none";
        } catch (IOException e) {
            return "none";
        }
    }

    /** THUMB_W x THUMB_H ARGB pixels of the saved face, or null if there is no preview (e.g. videos). */
    public static int[] readThumb(Path game, String name) {
        try {
            Path dir = savedDirFor(game, name);
            Path t = dir.resolve("thumb.png");
            BufferedImage im = Files.isRegularFile(t) ? ImageIO.read(t.toFile()) : null;
            if (im == null || im.getWidth() != THUMB_W || im.getHeight() != THUMB_H) {
                // missing, or an older-version thumbnail: rebuild it from the saved image
                Path img = savedImage(dir);
                if (img == null) return null;
                ShieldPackBuilder.writeThumb(img, t, ShieldPackBuilder.Settings.load(settingsFile(game)).fit);
                im = ImageIO.read(t.toFile());
                if (im == null) return null;
            }
            return im.getRGB(0, 0, THUMB_W, THUMB_H, null, 0, THUMB_W);
        } catch (Exception e) {
            return null;
        }
    }

    /** Resolves a saved shield folder, refusing names that try to escape the saved/ folder. */
    private static Path savedDirFor(Path game, String name) throws IOException {
        String clean = cleanName(name);
        if (clean.isEmpty() || !clean.equals(name)) throw new IOException("Bad shield name: " + name);
        return savedDir(game).resolve(clean);
    }

    private static Path savedImage(Path dir) {
        try (Stream<Path> s = Files.list(dir)) {
            return s.filter(Files::isRegularFile)
                    .filter(p -> p.getFileName().toString().startsWith("image.") && EXT.contains(ext(p)))
                    .findFirst().orElse(null);
        } catch (IOException e) {
            return null;
        }
    }

    private static void clearDir(Path dir) throws IOException {
        try (Stream<Path> s = Files.list(dir)) {
            for (Path p : s.toList()) if (Files.isRegularFile(p)) Files.deleteIfExists(p);
        }
    }

    private static void removeCustomFiles(Path game) throws IOException {
        Path dir = inputDir(game);
        if (!Files.isDirectory(dir)) return;
        try (Stream<Path> s = Files.list(dir)) {
            for (Path p : s.toList()) {
                String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                if (n.startsWith("custom.") && EXT.contains(ext(p))) Files.deleteIfExists(p);
            }
        }
    }

    private static String ext(Path p) {
        String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
        int dot = n.lastIndexOf('.');
        return dot < 0 ? "" : n.substring(dot + 1);
    }
}
